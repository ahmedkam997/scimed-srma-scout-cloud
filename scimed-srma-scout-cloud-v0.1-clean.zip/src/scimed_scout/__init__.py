"""SciMed SRMA Scout Cloud core package."""
__version__ = "0.1.0"
